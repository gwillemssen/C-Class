#ifndef LOGIC_H
#define LOGIC_H

#include <stdbool.h>
#include <stdlib.h>

bool is_palindrome(char *, size_t);

#endif
